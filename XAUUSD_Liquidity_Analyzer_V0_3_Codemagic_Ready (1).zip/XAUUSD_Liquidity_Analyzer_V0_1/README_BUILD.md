# XAUUSD Liquidity Analyzer V0.3 - Test Build

## Build target
Android debug APK, analysis-only.

## Included markets
- XAU/USD
- NASDAQ
- US30
- BTC/USD

## Included analysis
- M1/M5/M30 data gate
- liquidity/sweep detection
- displacement/MSS proxy
- FVG proxy
- BUY/SELL confluence score
- entry/SL/TP/R:R display
- risk profile selector
- test/synthetic model
- Twelve Data REST test connector
- provider symbol override
- analysis-only; no broker credentials and no automatic execution

## Codemagic
The repository root contains `codemagic.yaml`. The first build is intentionally a debug APK and does not require release signing.

## Important
The project must be built with a cloud Android toolchain. This environment does not contain the Android SDK, so a local APK compile could not be performed here.
