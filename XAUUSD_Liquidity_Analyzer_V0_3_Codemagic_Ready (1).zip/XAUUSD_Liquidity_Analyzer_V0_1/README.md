# XAUUSD Liquidity Analyzer — Multi-Asset Test Build 0.2

Android/Jetpack Compose analysis-only application for liquidity/sweep/MSS/FVG style market analysis.

## Included
- XAU/USD, NASDAQ, US30 and BTC/USD market selector
- Provider-symbol override so the exact data-provider symbol can be entered
- Twelve Data REST connector for M1/M5/M30 OHLC data
- Feed settings dialog and API-key input for testing
- Data gate: M1/M5/M30 plus session/liquidity readiness
- Liquidity sweep, displacement, MSS and FVG checks
- BUY/SELL confluence score
- Entry / SL / TP1 / TP2 / R:R display
- Conservative / Normal / Aggressive risk profile UI
- Alerts and live-polling switches
- Synthetic test model that runs without an API key
- No broker credentials and no automatic trading

## Data-provider notes
Twelve Data's official documentation supports `/time_series` with intraday intervals including 1min, 5min and 30min. Its WebSocket supports real-time quote streaming; this test build uses REST polling to reduce Android networking complexity. For a production release, put the API key behind a secure backend rather than shipping a permanent secret inside the APK.

The index symbols used by CFD brokers may differ from the underlying index symbols supplied by a market-data provider. Use the FEED symbol override and validate the provider's exact symbol before trusting signals.

## Build
This environment does not contain the Android SDK/Gradle toolchain, so an APK cannot be compiled here. Open this folder in Android Studio, sync Gradle and build the debug APK.
