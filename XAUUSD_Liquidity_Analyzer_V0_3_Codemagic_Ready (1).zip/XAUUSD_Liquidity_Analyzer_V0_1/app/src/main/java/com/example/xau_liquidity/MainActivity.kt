package com.example.xau_liquidity

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL
import java.text.SimpleDateFormat
import java.util.*
import kotlin.math.abs

private data class Candle(val t: Long, val o: Double, val h: Double, val l: Double, val c: Double, val v: Double = 0.0)
private data class Analysis(
    val ready: Boolean, val completeness: Int, val sweep: String, val displacement: String,
    val mss: String, val fvg: String, val bias: String, val buy: Int, val sell: Int,
    val entry: String, val sl: String, val tp1: String, val tp2: String, val rr: String,
    val reason: String
)

class MainActivity : ComponentActivity() {
    override fun onCreate(b: Bundle?) { super.onCreate(b); setContent { App() } }
}

@Composable
fun App() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    var asset by remember { mutableStateOf("XAU/USD") }
    var custom by remember { mutableStateOf("") }
    var apiKey by remember { mutableStateOf("") }
    var connected by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("TEST MODEL READY — feed not connected") }
    var risk by remember { mutableStateOf("NORMAL") }
    var alerts by remember { mutableStateOf(true) }
    var analysis by remember { mutableStateOf(mockAnalysis(asset)) }
    var showSettings by remember { mutableStateOf(false) }
    var autoRefresh by remember { mutableStateOf(false) }

    MaterialTheme {
        Scaffold { pad ->
            LazyColumn(Modifier.fillMaxSize().padding(pad).padding(14.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
                item {
                    Surface(tonalElevation = 3.dp, modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("Liquidity Analyzer", fontWeight = FontWeight.Bold)
                            TextButton(onClick = { showSettings = true }) { Text("FEED") }
                        }
                    }
                }
                item {
                    Text("MULTI-ASSET • ANALYSIS ONLY", fontWeight=FontWeight.Bold)
                    Text("XAUUSD • NASDAQ • US30 • BITCOIN", style=MaterialTheme.typography.bodySmall)
                }
                item { AssetSelector(asset) { asset=it; analysis=mockAnalysis(it) } }
                item { StatusCard(connected, analysis.completeness, message) }
                item { Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.spacedBy(10.dp)) { Score("BUY", "${analysis.buy}%"); Score("SELL", "${analysis.sell}%") } }
                item { Section("DATA GATE") {
                    listOf("M30 candles" to analysis.ready, "M5 candles" to analysis.ready, "M1 candles" to analysis.ready,
                        "Asian H/L" to analysis.ready, "London H/L" to analysis.ready, "Previous Day H/L" to analysis.ready,
                        "Session clock" to true).forEach { (n, ok) -> Text("${if(ok) "✓" else "•"} $n: ${if(ok) "READY" else "WAITING"}") }
                } }
                item { Section("LIQUIDITY / SETUP ENGINE") {
                    Text("Liquidity sweep: ${analysis.sweep}"); Text("Displacement: ${analysis.displacement}"); Text("MSS: ${analysis.mss}"); Text("FVG / iFVG: ${analysis.fvg}")
                } }
                item { Section("SIGNAL") {
                    if (!analysis.ready) Text("LOCKED — ${analysis.reason}", fontWeight=FontWeight.Bold)
                    else { Text("BIAS: ${analysis.bias}", fontWeight=FontWeight.Bold); Text("Entry: ${analysis.entry}"); Text("SL: ${analysis.sl}"); Text("TP1: ${analysis.tp1}"); Text("TP2: ${analysis.tp2}"); Text("R:R: ${analysis.rr}") }
                } }
                item { Section("RISK PROFILE") { Row(horizontalArrangement=Arrangement.spacedBy(5.dp)) { listOf("CONSERVATIVE","NORMAL","AGGRESSIVE").forEach { FilterChip(selected=risk==it,onClick={risk=it},label={Text(it)}) } }; Text("Selected: $risk") } }
                item { Section("ALERTS / TEST") {
                    Row { Switch(checked=alerts,onCheckedChange={alerts=it}); Text(if(alerts) " Alerts ON" else " Alerts OFF") }
                    Row { Switch(checked=autoRefresh,onCheckedChange={autoRefresh=it}); Text(if(autoRefresh) " Live polling ON" else " Live polling OFF") }
                    Button(enabled=!busy,onClick={
                        busy=true; message="Downloading M1/M5/M30…"
                        val symbol=(custom.trim().ifEmpty{asset})
                        Thread { val result=loadLive(symbol, apiKey); runOnUiThread {
                            busy=false; if(result.first!=null){ connected=true; analysis=result.first!!; message=result.second } else { connected=false; message=result.second }
                        }}
                    },Modifier.fillMaxWidth()) { Text(if(busy) "WORKING…" else "ANALYZE LIVE FEED") }
                    OutlinedButton(onClick={ analysis=mockAnalysis(asset); connected=false; message="Synthetic test candles loaded — no live trade signal" },Modifier.fillMaxWidth()){Text("RUN TEST MODEL")}
                } }
                item { Section("WHY NO SIGNAL?") { Text(if(analysis.ready) "All required data passed. Setup engine evaluated liquidity → sweep → displacement → MSS → FVG/iFVG." else analysis.reason) } }
                item { Text("Version 0.2 test • No broker credentials • No automatic execution • Manual trading only") }
            }
        }
    }

    if(showSettings) FeedSettings(apiKey, {apiKey=it}, custom, {custom=it}, { showSettings=false })
}

@Composable fun AssetSelector(asset:String,onPick:(String)->Unit) {
    Section("MARKET") { listOf("XAU/USD","NASDAQ","US30","BTC/USD").forEach { FilterChip(selected=asset==it,onClick={onPick(it)},label={Text(it)}) }; Text("Provider symbol can be overridden in FEED settings.") }
}

@Composable fun FeedSettings(apiKey:String,setKey:(String)->Unit, custom:String,setCustom:(String)->Unit,close:()->Unit) {
    AlertDialog(onDismissRequest=close,confirmButton={Button(onClick=close){Text("SAVE")}},title={Text("DATA FEED SETTINGS")},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("Twelve Data REST test connector",fontWeight=FontWeight.Bold)
        OutlinedTextField(value=apiKey,onValueChange=setKey,label={Text("API key (test only)")},singleLine=true)
        OutlinedTextField(value=custom,onValueChange=setCustom,label={Text("Provider symbol override")},singleLine=true,placeholder={Text("XAU/USD, BTC/USD, index symbol…")})
        Text("The app requests 1min, 5min and 30min OHLC data and locks signals until the required dataset passes. For production, move the key behind a secure backend.")
        Text("Twelve Data supports time-series intervals including 1min/5min/30min and WebSocket streaming; this build uses REST polling for simpler phone-only testing.")
    }})
}

@Composable fun StatusCard(connected:Boolean,pct:Int,msg:String) = Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text("DATA QUALITY",fontWeight=FontWeight.Bold);Text("Feed: ${if(connected) "CONNECTED" else "TEST / NOT CONNECTED"}");Text("Completeness: $pct% required data");Text(msg)}}
@Composable fun Score(label:String,value:String)=Card(Modifier.weight(1f)){Column(Modifier.padding(14.dp)){Text(label,fontWeight=FontWeight.Bold);Text(value,style=MaterialTheme.typography.headlineMedium);Text("Confluence score")}}
@Composable fun Section(title:String,content:@Composable ColumnScope.()->Unit)=Card(Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text(title,fontWeight=FontWeight.Bold);content()}}

private fun mockAnalysis(asset:String):Analysis {
    val seed=asset.hashCode().toLong(); val r=Random(seed); val buy=55+r.nextInt(31); val sell=100-buy
    return Analysis(true,100,"DETECTED","CONFIRMED","CONFIRMED","BULLISH FVG","BUY",buy,sell,"TEST ENTRY","TEST SL","TEST TP1","TEST TP2","1:3","Synthetic candles only")
}

private fun loadLive(symbol:String,key:String):Pair<Analysis?,String> {
    if(key.isBlank()) return null to "Enter a Twelve Data API key in FEED settings, or use RUN TEST MODEL."
    return try {
        val m1=fetch(symbol,"1min",key,2000); val m5=fetch(symbol,"5min",key,1000); val m30=fetch(symbol,"30min",key,500)
        if(m1.size<200 || m5.size<100 || m30.size<50) return null to "Feed connected, but not enough candles for the data gate."
        analyze(symbol,m1,m5,m30) to "Live OHLC data loaded for $symbol"
    } catch(e:Exception){ null to "Feed error: ${e.message ?: "unknown error"}" }
}

private fun fetch(symbol:String,interval:String,key:String,size:Int):List<Candle>{
    val q=URLEncoder.encode(symbol,"UTF-8"); val url=URL("https://api.twelvedata.com/time_series?symbol=$q&interval=$interval&outputsize=$size&timezone=UTC&apikey=${URLEncoder.encode(key,"UTF-8")}")
    val c=url.openConnection() as HttpURLConnection; c.connectTimeout=12000; c.readTimeout=15000
    val text=c.inputStream.bufferedReader().use{it.readText()}; c.disconnect(); val root=JSONObject(text)
    if(root.has("status") && root.getString("status")!="ok") throw Exception(root.optString("message","API error"))
    val arr=root.optJSONArray("values") ?: throw Exception("No candle data returned")
    val out=mutableListOf<Candle>(); val df=SimpleDateFormat("yyyy-MM-dd HH:mm:ss",Locale.US); df.timeZone=TimeZone.getTimeZone("UTC")
    for(i in 0 until arr.length()){val o=arr.getJSONObject(i);out+=Candle(df.parse(o.getString("datetime"))!!.time,o.getDouble("open"),o.getDouble("high"),o.getDouble("low"),o.getDouble("close"),o.optDouble("volume",0.0))}
    return out.sortedBy{it.t}
}

private fun analyze(asset:String,m1:List<Candle>,m5:List<Candle>,m30:List<Candle>):Analysis {
    val recent=m5.takeLast(60); val prev=recent.dropLast(3); val hi=prev.maxOf{it.h}; val lo=prev.minOf{it.l}; val last=recent.last();
    val sweptHigh=last.h>hi && last.c<hi; val sweptLow=last.l<lo && last.c>lo
    val bullish=last.c>last.o && last.c>recent[recent.size-2].h; val bearish=last.c<last.o && last.c<recent[recent.size-2].l
    val buyPoints=listOf(sweptLow,bullish,last.c>m30.takeLast(20).map{it.c}.average(),hasFvg(recent,true)).count{it}
    val sellPoints=listOf(sweptHigh,bearish,last.c<m30.takeLast(20).map{it.c}.average(),hasFvg(recent,false)).count{it}
    val buy=50+buyPoints*12; val sell=50+sellPoints*12; val ready=(sweptHigh||sweptLow)&&(bullish||bearish)&&hasFvg(recent,buyPoints>=sellPoints)
    val bias=if(buy>sell)"BUY" else if(sell>buy)"SELL" else "NEUTRAL"; val e=last.c; val range=(last.h-last.l).coerceAtLeast(e*0.0005); val sl=if(bias=="BUY")e-range*1.2 else e+range*1.2; val tp1=if(bias=="BUY")e+range*2.4 else e-range*2.4; val tp2=if(bias=="BUY")e+range*3.6 else e-range*3.6
    return Analysis(true,100,if(sweptHigh||sweptLow)"DETECTED" else "NOT DETECTED",if(bullish||bearish)"CONFIRMED" else "WAITING",if(bullish||bearish)"CONFIRMED" else "WAITING",if(hasFvg(recent,buy>=sell))"CONFIRMED" else "WAITING",bias,buy.coerceAtMost(99),sell.coerceAtMost(99),"%.5f".format(e),"%.5f".format(sl),"%.5f".format(tp1),"%.5f".format(tp2),"1:2.0–1:3.0",if(ready)"Setup passed the simplified test gate." else "Waiting for sweep + displacement + MSS/FVG confirmation. $asset data is live but the model is intentionally conservative.")
}
private fun hasFvg(c:List<Candle>,bull:Boolean):Boolean { if(c.size<4)return false; val a=c[c.size-3]; val b=c[c.size-1]; return if(bull)b.l>a.h else b.h<a.l }
